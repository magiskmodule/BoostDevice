SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE="
"
print_modname() {
  ui_print "°°°·.°·..·°¯°·._.·     ·._.·°¯°·..·°.·°°°"
  ui_print "              𝐁𝐎𝐎𝐒𝐓 𝐃𝐄𝐕𝐈𝐂𝐄               "
  ui_print "           𝗞𝘂𝘁𝘂 𝗠𝗼𝗯𝗮 𝗫 𝗭𝗢𝗘𝗥𝗛𝗡                   "
  ui_print "°°°·.°·..·°¯°·._.·     ·._.·°¯°·..·°.·°°°"
sleep 2
}
on_install() {
  ui_print " 𝐁𝐮𝐢𝐥𝐝 𝐃𝐚𝐭𝐞 : 𝟏𝟗 - 𝟏𝟏 - 𝟐𝟎𝟐𝟑"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  set_permissions
sleep 3
ui_print " 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 𝟑.𝟎"
    sleep 3
    ui_print " 𝐆𝐞𝐭𝐭𝐢𝐧𝐠 𝐃𝐞𝐯𝐢𝐜𝐞 𝐈𝐧𝐟𝐨.."
    sleep 4
    ui_print ""
    sleep 2
    ui_print " 𝐀𝐧𝐝𝐫𝐨𝐢𝐝 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : $(getprop ro.build.version.release)"
    sleep 2
  ui_print " 𝐁𝐫𝐚𝐧𝐝 : $(getprop ro.product.system.manufacturer)"
  sleep 2
  ui_print " 𝐂𝐩𝐮 : $(getprop ro.hardware)"
  sleep 2
  ui_print " 𝐃𝐞𝐯𝐢𝐜𝐞 : $(getprop ro.product.model)"
  sleep 2
  ui_print " 𝐊𝐞𝐫𝐧𝐞𝐥 : $(uname -r)"
  sleep 2
  ui_print " 𝐑𝐚𝐦 : $(free | grep Mem |  awk '{print $2}')"
  sleep 2
  ui_print " "
  ui_print " 𝙍𝙪𝙣 𝙏𝙝𝙞𝙨 𝘾𝙤𝙢𝙢𝙖𝙣𝙙 𝙞𝙣 𝙏𝙚𝙧𝙢𝙪𝙭 / 𝙏𝙚𝙧𝙢𝙞𝙣𝙖𝙡 "
sleep 2
  ui_print " 𝐬𝐮 -𝐜 𝐛𝐨𝐬𝐭𝐫   "
sleep 3
  ui_print ""
sleep 0.5
  ui_print " 𝐃𝐖𝐘𝐎𝐑, 𝐃𝐨 𝐖𝐢𝐭𝐡 𝐘𝐨𝐮𝐫 𝐎𝐰𝐧 𝐑𝐢𝐬𝐤         "
sleep 2
  ui_print ""
}
set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0755
  set_perm $MODPATH/system/bin/bostr 0 0 0755 0755
  set_perm $MODPATH/system/etc/init.d/ 0 0 0755 0755
}

# 
